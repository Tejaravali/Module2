
public class TestAccount 
{
	public static void main(String args[])
	{
		Person accHolder1=new Person("Smith",20);
		Person accHolder2=new Person("kathy",30);
		long accNum1=Math.round(Math.random()*10000);
		long accNum2=Math.round(Math.random()*10000);
		Account acc1=new Account(accNum1,2000,accHolder1);
		Account acc2=new Account(accNum2,2000,accHolder2);
		System.out.println(acc1);
		System.out.println(acc2);
		acc1.deposit(2000);
		acc2.withdraw(3000);
		System.out.println("Updated Balances are: ");
		System.out.println("For Smith : "+acc1.getBalance());
		System.out.println("For Kathy : "+acc2.getBalance());
	}

}
