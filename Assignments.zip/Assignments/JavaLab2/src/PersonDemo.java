
public class PersonDemo
{

	private String firstName;
	private String lastName;
	private char gender;
	private int age;
	private float weight;
	
	public PersonDemo(String firstName, String lastName, char gender, int age,
			         float weight) 
	{
	
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
	}
	
	public String dispPersonDetails()
	{
		return "First Name:"+firstName+"\n"
				+"Last Name:"+lastName+"\n"
				+"Gender:"+gender+"\n"
				+"Age:"+age+"\n"
				+"Weight:"+weight;
	}
	
	
	

}
