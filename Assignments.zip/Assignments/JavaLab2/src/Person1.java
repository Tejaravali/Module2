
public class Person1
{
	 private String firstName;
	    private String lastName;
	    private char Gender;
	    private long PhoneNumber;
	    
	public Person1()
	{
	}
	public String getfirstName()
	{
	    return firstName;
	}
	public String getlastName()
	{
	    return lastName;
	}
	public char getGender()
	{
	    return Gender;
	}
	public long getPhoneNumber()
	{
	    return PhoneNumber;
	}
	public void setfirstName(String firstName)
	{
	    this.firstName=firstName;
	}
	public void setlastName(String lastName)
	{
	    this.lastName=lastName;
	}
	public void setGender(char Gender)
	{
	    this.Gender=Gender;
	}
	public void setPhoneNumber(long PhoneNumber)
	{
	    this.PhoneNumber=PhoneNumber;
	}
	public String dispperInfo(){
	    return "Person Details :"+"\n"
	            +"______________"+"\n"+"\n"
	            
	            +"First Name:"+firstName+"\n"
	            +"Last Name:"+lastName+"\n"
	            +"Gender :"+Gender+"\n"
	            +"PhoneNumber :"+PhoneNumber;          
	            

}
}
