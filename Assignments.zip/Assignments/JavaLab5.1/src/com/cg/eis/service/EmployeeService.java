package com.cg.eis.service;

public interface EmployeeService
{
	public String employeeServiceScheme(float empSal,String empDes);
	

}
