package com.cg.eis.bean;

import com.cg.eis.service.ServiceClass;

public class Employee 
{
	private int empId;
	private String empName;
	private float empSal;
	private String empDes;
	ServiceClass empIns;
	public int getEmpId() 
	{
		return empId;
	}
	public void setEmpId(int empId) 
	{
		this.empId = empId;
	}
	public String getEmpName()
	{
		return empName;
	}
	public void setEmpName(String empName) 
	{
		this.empName = empName;
	}
	public float getEmpSal()
	{
		return empSal;
	}
	public void setEmpSal(float empSal)
	{
		this.empSal = empSal;
	}
	public String getEmpDes() 
	{
		return empDes;
	}
	public void setEmpDes(String empDes) 
	{
		this.empDes = empDes;
	}
	public ServiceClass getEmpIns()
	{
		return empIns;
	}
	public void setEmpIns(ServiceClass empIns)
	{
		this.empIns = empIns;
	}
	public Employee() 
	{
		super();
		
	}
	public Employee(int empId, String empName, float empSal, String empDes,
			ServiceClass empIns) 
	{
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDes = empDes;
		this.empIns = empIns;
	}
	
	public String dispEmpInfo() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + ", empDes=" + empDes + ", empIns="
				+ empIns.employeeServiceScheme(empSal,empDes) + "]";
	}
}
