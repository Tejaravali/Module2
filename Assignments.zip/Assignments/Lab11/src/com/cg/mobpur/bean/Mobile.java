package com.cg.mobpur.bean;

public class Mobile 
{
	private int mobileId;
	private String name;
	private Float price;
	private int quantity;
	public int getMobileId() 
	{
		return mobileId;
	}
	public void setMobileId(int mobileId) 
	{
		this.mobileId = mobileId;
	}
	public String getName() 
	{
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	public Float getPrice() 
	{
		return price;
	}
	public void setPrice(Float price) 
	{
		this.price = price;
	}
	public int getQuantity() 
	{
		return quantity;
	}
	public void setQuantity(int quantity) 
	{
		this.quantity = quantity;
	}
	public Mobile() 
	{
		super();

	}
	public Mobile(int mobileId, String name, Float price, int quantity)
	{
		super();
		this.mobileId = mobileId;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	@Override
	public String toString() 
	{
		return "Mobile [mobileId=" + mobileId + ", name=" + name + ", price="
				+ price + ", quantity=" + quantity + "]";
	}
}
