package com.cg.mobpur.bean;

public class Purchase 
{
     private String cName;
     private String mailId;
     private long  mobileNumber;
     private int   purchaseId;
     private int  mobileId;
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public Purchase() {
		super();
	
	}
	public Purchase(String cName, String mailId, long mobileNumber,
			int purchaseId, int mobileId) {
	
		this.cName = cName;
		this.mailId = mailId;
		this.mobileNumber = mobileNumber;
		this.purchaseId = purchaseId;
		this.mobileId = mobileId;
	}
	@Override
	public String toString() {
		return "Purchase [cName=" + cName + ", mailId=" + mailId
				+ ", mobileNumber=" + mobileNumber + ", purchaseId="
				+ purchaseId + ", mobileId=" + mobileId + "]";
	}
 }
