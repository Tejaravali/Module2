package com.cg.mobpur.service;

import java.util.ArrayList;
import java.util.regex.Pattern;
import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.dao.MobDao;
import com.cg.mobpur.dao.MobDaoImpl;
import com.cg.mobpur.exception.MobileException;

public class MobServiceImpl implements MobService
{

	MobDao mobDao=null;
	public MobServiceImpl()
	{
		mobDao=new MobDaoImpl();
	}

	@Override
	public int insertCustomer(Purchase ps) throws MobileException 
	{
		return mobDao.insertCustomer(ps);
	}

	@Override
	public int generatePurchaseId() throws MobileException 
	{

		return mobDao.generatePurchaseId();
	}

	@Override
	public ArrayList<Mobile> getAllMob() throws MobileException 
	{
		return mobDao.getAllMob();
	}

	@Override
	public ArrayList<Integer> getAllMobIds() throws MobileException
	{
		return mobDao.getAllMobIds();
	}
	
	@Override
	public int updateQuantity(int mobileId) throws MobileException
	{
		return mobDao.updateQuantity(mobileId);
	}
	@Override
	public int deleteMobile(int mobileId) throws MobileException
	{
		return mobDao.deleteMobile(mobileId);
	}
	@Override
	public ArrayList<Mobile> searchMobile(float min, float max)
			throws MobileException 
    {
		return mobDao.searchMobile(min,max);
	}
	
	@Override
	public boolean validateName(String cName) throws MobileException
	{
		String namePattern="[A-Z][a-z]{3,19}";
		if(Pattern.matches(namePattern, cName))
		{
			return true;
		}
		else
		{
			throw new MobileException("Only Chars Allowed and starts "
					+ "with Capital");
		}
     }
   @Override
	public boolean validateMobileNumber(Long MobileNumber)
			throws MobileException 
	{
		String numPattern="[7-9][0-9]{9}";
		if(Pattern.matches(numPattern, new Long(MobileNumber).toString()))
		{
		     return true;
		}
		else
		{
			throw new MobileException("Mobile number must be valid");
		}
	}

@Override
public boolean validateMobileId(int MobileId) throws MobileException 
{
	  mobDao = new MobDaoImpl();
     String midPattern="[0-9]{4}$";
     ArrayList<Integer> idList=mobDao.getAllMobIds();
     String mob = String.valueOf(MobileId);
     if(Pattern.matches(midPattern,mob))
     {
         for(Integer i:idList)
         {
             if(MobileId==i)
             {
                 return true;
             }
         }
     }
     return false;
 }


@Override
public boolean validateMailId(String MailId) throws MobileException 
{
	 String mailPattern="[a-z]+[@][a-z]{5}[.][a-z]{1,3}";
     if(Pattern.matches(mailPattern, MailId))
     {
         return true;
     }
     else
     {
         throw new MobileException("Invalid Mail Id");
     }
 }

@Override
public boolean validategetAllMobQuantity(Purchase ps) throws MobileException 
{

	mobDao = new MobDaoImpl();
	int quantity=mobDao.getAllMobQuantity(ps);
    if(quantity>0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
}




