package com.cg.mobpur.service;

import java.util.ArrayList;
import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.exception.MobileException;

public interface MobService
{

	 public int insertCustomer(Purchase ps) throws MobileException;
	 public int generatePurchaseId() throws MobileException;
	 public ArrayList<Mobile>  getAllMob() throws MobileException;
	 public ArrayList<Integer>  getAllMobIds() throws MobileException;
	 public boolean validategetAllMobQuantity(Purchase ps) throws MobileException;
	 public boolean validateName(String cName) throws MobileException;
     public boolean validateMobileNumber(Long MobileNumber) throws MobileException;
     public boolean validateMobileId(int MobileId) throws MobileException;
     public boolean validateMailId(String MailId) throws MobileException;
     public int updateQuantity(int mobileId) throws MobileException;
     public int deleteMobile(int mobileId) throws MobileException;
     public ArrayList<Mobile>  searchMobile(float min,float max) throws MobileException;
     
}
