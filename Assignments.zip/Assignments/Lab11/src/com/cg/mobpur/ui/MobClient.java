package com.cg.mobpur.ui;


import java.util.ArrayList;
import java.util.Scanner;
import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.exception.MobileException;
import com.cg.mobpur.service.MobService;
import com.cg.mobpur.service.MobServiceImpl;


public class MobClient 
{
	static Scanner sc=null;
	static MobService mob=null;
	public static void main(String[] args) 
	{
		mob=new MobServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		while(true)
		{
			System.out.println("What do you want to do?");
			System.out.println("1.Add Purchases 2.Fetch Mobiles 3.Delete 4.Search 5.Exit");

			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				insertPurchases();
				break;
			case 2:
				fetchAllMobiles();
				break;
			case 3:
				deleteMob();
				break;
			case 4:
				searchMob();
				break;

			default:
				System.exit(0);
			}
		}
	}
	public static void insertPurchases() 
	{
		System.out.println("Enter customer name");
		String cName=sc.next();
		System.out.println("Enter customer mail id ");
		String MailId=sc.next();
		System.out.println("Enter customer phone number");
		Long MobileNumber=sc.nextLong();
		System.out.println("Enter Mobile Id");
		int MobileId=sc.nextInt();
		try 
		{
			if(mob.validateName(cName) && mob.validateMailId(MailId) && mob.validateMobileNumber(MobileNumber) && mob.validateMobileId(MobileId))
			{
				int dataAdded = 0;
				Purchase ps=new Purchase();
				ps.setcName(cName);
				ps.setMailId(MailId);
				ps.setMobileNumber(MobileNumber);
				ps.setMobileId(MobileId);
				if(mob.validategetAllMobQuantity(ps))
				{
					dataAdded = mob.insertCustomer(ps);
				}
				if(dataAdded==1)
				{
					System.out.println("Employee data added");
					updateMobiles(MobileId);
				}
				else{
					System.out.println("Some exception may be encountered while insertion");

				}
			}
		} 
		catch (MobileException e) {

			System.out.println(e.getMessage());
		}
	}

	/***************************************************************/
	public static void fetchAllMobiles()
	{
		try
		{
			ArrayList<Mobile> mobList=mob.getAllMob();
			for(Mobile m:mobList)
			{
				System.out.println(m);
			}
		}
		catch(MobileException e)
		{
			System.out.println("Some Exception while fetching data");
		}

	}
	/*****************************************************************/
	public static void updateMobiles(int mobileId)
	{

		int rows=0;
		try
		{
			rows=mob.updateQuantity(mobileId);
			if(rows>0)
			{
				System.out.println(rows+"rows updated");
			}
			else
			{
				System.out.println("Some Exceptions Occured");
			}
		}   
		catch(MobileException e)
		{
			System.out.println("Some Exception while fetching data");
		}

	}
	/*****************************************************************/
	public static void deleteMob()
	{
		System.out.println("Enter mobile id:");
		int mid=sc.nextInt();
		try
		{
			Mobile mb=new Mobile();
			mb.setMobileId(mid);
			int dataDeleted=mob.deleteMobile(mid);
			if(dataDeleted==1)
			{
				System.out.println("Data Deleted:");
			}
			else
			{
				System.out.println("Some Exceptions Occured");
			}
		}   
		catch(MobileException e)
		{
			System.out.println("Some Exception while fetching data");
		}
	}
	/*****************************************************/
	public static void searchMob()
	{
		float min=0;
		float max=0;
		System.out.println("Enter minimum Range:");
		min=sc.nextFloat();
		System.out.println("enter maximum Range:");
		max=sc.nextFloat();
		try
		{
			ArrayList<Mobile> empList=mob.searchMobile(min,max);
			for(Mobile m:empList)
			{
				System.out.println(m);
			}
		}
		catch(MobileException e)
		{
			System.out.println("Some Exception while fetching data");
			e.printStackTrace();
		}
	}

}








