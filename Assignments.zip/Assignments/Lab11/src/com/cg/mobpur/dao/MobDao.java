package com.cg.mobpur.dao;

import java.util.ArrayList;
import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.exception.MobileException;

public interface MobDao 
{
	 public int insertCustomer(Purchase ps) throws MobileException;
	 public int generatePurchaseId() throws MobileException;
	 public ArrayList<Mobile>  getAllMob() throws MobileException;
	 public ArrayList<Integer>  getAllMobIds() throws MobileException;
	 public int getAllMobQuantity(Purchase ps) throws MobileException;
	 public int updateQuantity(int mobileId) throws MobileException;
	 public int deleteMobile(int mobileId) throws MobileException;
	 public ArrayList<Mobile>  searchMobile(float min,float max) throws MobileException;

}
