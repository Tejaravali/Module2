import java.util.Scanner;


public class TestBankAppDemo
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int currentBalance=60000;
		
		System.out.println(" "+ "Enter the Withdraw Amount");
		int withdrawAmt=sc.nextInt();
		if(withdrawAmt<currentBalance)
		{
			System.out.println("Ok U Have sufficient bala U can withdraw");
		}
		else
		{
			try
			{
			throw new LowBalanceException
			  ("Please Chk balance of ur Account");
			}
			catch(LowBalanceException e)
			{
				System.out.println("Insufficient Balance ");
			}
		}
		
	}

}
