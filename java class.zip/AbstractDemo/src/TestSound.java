
public class TestSound 
{

	public static void main(String[] args)
	{
		Animal obj= new Lion();
		obj.Sound();

	}

}
