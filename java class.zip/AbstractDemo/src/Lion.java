
public class Lion extends Animal
{
	public void Sound()
	{
		System.out.println("roar");
	}

}
