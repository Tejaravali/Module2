import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;


public class TestEmpUpdateDemo
{

	public static void main(String[] args)
	{
		Connection con=null;
		Statement st=null;

		try
		{

			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			st=con.createStatement();
			String updateQry="UPDATE emp_142784 SET emp_Sal=emp_Sal+1000 where emp_Sal<5000";
			int data=st.executeUpdate(updateQry);
			System.out.println("Data Updated"+data);

		}		
		catch (Exception e) 
		{

			e.printStackTrace();
		}
	}

}


