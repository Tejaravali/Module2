import java.sql.*;


public class TestEmpSelectDemo 
{

	public static void main(String[] args) 
	{
		//Load Oracle type 4 driver in memory
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			st=con.createStatement();
			String selQuery="SELECT emp_id,emp_name,emp_sal FROM emp_142784";
			rs=st.executeQuery(selQuery);
			
			while(rs.next())
				{
			System.out.println(" ID \t NAME \t SALARY");
			System.out.println(rs.getInt("emp_id")+"\t"+rs.getString("emp_name")
					+"\t"+rs.getInt("emp_sal"));
				}
			
			
		         } 
		catch (Exception e) 
		{

			e.printStackTrace();
		}
	}

}
