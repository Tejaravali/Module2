import java.sql.*;
import java.util.Scanner;

public class TestMenucaseDemo 
{
    public static void main(String[] args) 
    {
        Connection con=null;
        PreparedStatement pst=null;
        ResultSet rs;
        Statement st=null;
        Scanner sc=new Scanner(System.in);
        System.out.println("Select one of the below operations");
        System.out.println("1.Insert multiple rows into the table");
        System.out.println("2.Increase the salary of employees by 1000 if salary is less than 5000");
        System.out.println("3.Delete the record of a given employee id");
        System.out.println("4.Select all records");
        System.out.println("5.Select details of given employee id");
        System.out.println("6.Exit");
        int choice=sc.nextInt();
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
        switch(choice)
        {
        case 1:
            String insertQry;
            int dataAdded;
            insertQry="INSERT INTO emp_142784 VALUES(?,?,?,?)";
             pst=con.prepareStatement(insertQry);
            System.out.println("Enter number of records that should be inserted ");
            int n=sc.nextInt();
            for(int i=0;i<n;i++)
            {
            System.out.println("Enter ID :");
            int empId=sc.nextInt();
            
            System.out.println("Enter Name :");
            String empName=sc.next();
            
            System.out.println("Enter Salary :");
            int empSal=sc.nextInt();
            
            System.out.println("Enter DOJ :");
            String empDoj=sc.next();
            
             pst.setInt(1, empId);
             pst.setString(2,empName);
             pst.setInt(3, empSal);
             pst.setString(4, empDoj);
             dataAdded=pst.executeUpdate();
             System.out.println("Data is added "+dataAdded);
            }
            break;
        case 2:
            st=con.createStatement();
            String updateQry="UPDATE emp_142784 SET emp_sal=emp_sal+1000 WHERE emp_sal<5000";
            int data=st.executeUpdate(updateQry);
            System.out.println("Data updated in table. "+ data);
            break;
        case 3:
            String deleteQry;
            int data1;
             
            System.out.println("Enter ID :");
            int empId=sc.nextInt();
            deleteQry="DELETE FROM emp_142784 WHERE emp_id=?";
            pst=con.prepareStatement(deleteQry);
            pst.setInt(1, empId);
            data1=pst.executeUpdate();
            System.out.println("Data deleted from table. "+ data1);
            break;
        case 4:
            st=con.createStatement();
            String selectQuery="Select emp_id,emp_name,emp_sal from emp_142784";
            rs=st.executeQuery(selectQuery);
            
            System.out.println("ID \t Name \t \t Salary");
            while(rs.next())
            {
            System.out.println(rs.getInt("emp_id")+" \t "+rs.getString("emp_name")+"\t "+rs.getInt("emp_sal"));
            }
            break;
        case 5:
            System.out.println("Enter emp id to be selected");
            int empId1=sc.nextInt();
            
            String selectQry="Select emp_id,emp_name,emp_sal from emp_142784 where emp_id=?";
            
             pst=con.prepareStatement(selectQry);
              pst.setInt(1,empId1);
            System.out.println("ID \t Name \t \t Salary");
            
            rs=pst.executeQuery();
            rs.next();
            
            System.out.println(rs.getInt("emp_id")+" \t "+rs.getString("emp_name")+"\t "+rs.getInt("emp_sal"));
            
        }
        }
         catch (Exception e) {
          
            e.printStackTrace();
        }
    }
}