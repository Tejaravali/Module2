import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class TestEmpData2Demo 
{

	public static void main(String[] args) 
	{
		Connection con=null;
		Statement st=null;
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection
			("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			
			String insertQry="INSERT INTO emp_142784 "
					+ "(emp_id,emp_name,emp_sal)"
					+ "VALUES(666,'Kavitha',8000) ";
			st=con.createStatement();
			int data=st.executeUpdate(insertQry);
			System.out.println(" data Inserted in table:"+data);
			
		    } 
		    catch (Exception e) 
		    {

			e.printStackTrace();
		    }
	 }
}

