import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.*;


public class TestEmpDeleteDemo 
{
	public static void main(String[] args)
	{

		Connection con=null;
		Scanner sc=null;
		PreparedStatement pst;
		try
		{
			sc=new Scanner(System.in);
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");

			System.out.println("Enter Emp Id:");
			int empId=sc.nextInt();

			String insertQry="delete from emp_142784 where emp_id=?";
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,empId);
			int data=pst.executeUpdate();
			System.out.println("Data Updated");

		}		
		catch (Exception e) 
		{

			e.printStackTrace();
		}
	}
}
