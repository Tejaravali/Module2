
import java.util.TreeSet;


public class TestEmpTreeSetDemo 
{
	public static void main(String[] args)
	{
		TreeSet<Emp> empSet=new TreeSet<Emp>();
		
		Emp e1=new Emp(333,"Ravs",4000.0f);
		Emp e2=new Emp(111,"priya",5000.0f);
		Emp e3=new Emp(222,"Anu",6000.0f);
		Emp e4=new Emp(444,"Pari",7000.0f);
		Emp e5=new Emp(444,"Pari",7000.0f);
		
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
		empSet.add(e5);
		for(Emp tempE:empSet)
		{
			System.out.println(tempE);
		}
				
	}

}
