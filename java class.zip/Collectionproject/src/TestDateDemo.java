import java.time.LocalDate;
import java.time.*;
import java.time.format.DateTimeFormatter;


public class TestDateDemo 
{
	public static void main(String args[])
	{
		LocalDate today=LocalDate.now();
		System.out.println(" Today date :"+today);
		
		System.out.println("***********************");
		LocalDate myDOJ=LocalDate.of(2010, 04, 03);
		System.out.println(" My Date Of Join :"+myDOJ);
		
		System.out.println("***********************");
		String ronakDOJ="13-Dec-2017";
		DateTimeFormatter myFormat=
				DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate ronakDoj=LocalDate.parse(ronakDOJ,myFormat);
		System.out.println(" Ronal DOJ = "+ronakDoj);
		
		System.out.println("***********************");
		DateTimeFormatter secondFormat=
				DateTimeFormatter.ofPattern("yyyy-MMM-dd");
		
		String urDOJ=ronakDoj.format(secondFormat);
		System.out.println("...."+urDOJ);
		
		System.out.println("Difference");
		
		Period period=Period.between(myDOJ, today);
		int years=period.getYears();
		int month=period.getMonths();
		int day = period.getDays();
		
		System.out.println("my Exp In CG Is :"+years+"Years:"+month+"Months:"
				+day+"Days");
		
		
		}

}
