import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

import java.util.Set;

	  public class TestHashMapMobile 
	  {

		public static void main(String[] args)
		{
			HashMap<Long,String> mobileDirectory=new HashMap<Long,String>();
			
			mobileDirectory.put(9440129875L,"Ravs");
			mobileDirectory.put(8500633514L,"Mansi");
			mobileDirectory.put(9959304000L,"Bujji");
			mobileDirectory.put(9491079178L,"Nana");
			mobileDirectory.put(8333029049L,"Sindhu");
			
			  Set<Long> setIt=mobileDirectory.keySet();
			  for(Long key:setIt)
			 {
				 System.out.println(key);
			 }
		}

	}


