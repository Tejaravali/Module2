import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;


public class TestHashMapDemo
{

	public static void main(String[] args)
	{
		HashMap<Long,String> mobileDirectory=new HashMap<Long,String>();
		
		mobileDirectory.put(9440129875L,"Ravs");
		mobileDirectory.put(85006335145L,"Mansi");
		mobileDirectory.put(9959304000L,"Bujji");
		mobileDirectory.put(9491079178L,"Nana");
		mobileDirectory.put(8333029049L,"Sindhu");
		
		 Set<Entry<Long,String>> setIt=mobileDirectory.entrySet();
		 
		 Iterator<Entry<Long,String>> mobIt=setIt.iterator();
		 while(mobIt.hasNext())
		 {
			 Entry<Long,String> dirEntry=mobIt.next();
			 System.out.println("Mobile :"+dirEntry.getKey()+ " Name : "+
			                      dirEntry.getValue());
		 }
	}

}
