import java.util.*;


public class TestEmpArrayListDemo
{

	public static void main(String[] args)
	{
		ArrayList<Emp> empList=new ArrayList<Emp>();
		
		Emp e1=new Emp(333,"Ravs",4000.0f);
		Emp e2=new Emp(111,"priya",5000.0f);
		Emp e3=new Emp(222,"Anu",6000.0f);
		Emp e4=new Emp(333,"Pari",7000.0f);
		Emp e5=new Emp(333,"Peri",8000.0f);
		
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		empList.add(e5);
		
		System.out.println("************Print without using Iterator");
		System.out.println(empList);
		System.out.println("************Print  using Iterator");
		Iterator<Emp> empListIt=empList.iterator();
		while(empListIt.hasNext())
		{
			Emp tempEmp=empListIt.next();
			System.out.println(" ID : "+tempEmp.getEmpId());
			System.out.println(" Name : "+tempEmp.getEmpName());
			System.out.println(" Salary : "+tempEmp.getEmpSal());
		}
		


	}

}

