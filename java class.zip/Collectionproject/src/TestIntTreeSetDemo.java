
import java.util.Iterator;
import java.util.TreeSet;

    public class TestIntTreeSetDemo 
    {
		public static void main(String[] args)
		{
			
			TreeSet<Integer> intSet=new TreeSet<Integer>();
					
			Integer i1 = new Integer(10);//sorted and unique
			Integer i2 = new Integer(5);
			Integer i3 = new Integer(40);
			Integer i4 = new Integer(30);
			Integer i5 = new Integer(5);
			
			intSet.add(i1);
			intSet.add(i2);
			intSet.add(i3);
			intSet.add(i4);
			intSet.add(i5);
			
			
			System.out.println("********Without Iterator*********");
			System.out.println(intSet);
			System.out.println("*********With Iterator************");
			Iterator<Integer> it = intSet.iterator();//it points to prior first entry
			while(it.hasNext())//it.hasnext() pooints to first value
			{
				int tempEntry = it.next();//Auto unboxing
				System.out.println(" : "+tempEntry);
				
			}
			

		}

	}



