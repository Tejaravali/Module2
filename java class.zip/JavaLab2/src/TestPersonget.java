
public class TestPersonget
{
	public static void main(String[] args) {
        Personget p1= new Personget();
        p1.setfirstName("Divya");;
        p1.setlastName("Bharathi");
        p1.setGender('F');
        System.out.println("Person Details:");
        System.out.println("\n__________________");
        System.out.println("\n First Name :"+p1.getfirstName());
        System.out.println(" Last Name  : "+p1.getlastName());
        System.out.println(" Gender     : "+p1.getGender());
    }

}



