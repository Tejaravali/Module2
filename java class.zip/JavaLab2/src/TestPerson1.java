
public class TestPerson1 
{
	public static void main(String[] args) {
        Person1 p1= new Person1();
        p1.setfirstName("Divya");
        p1.setlastName("Bharathi");
        p1.setGender('F');
        p1.setPhoneNumber(9899949703l);
        System.out.println(p1.dispperInfo());

    }

}
