
public class TestPersonDemo
{

	public static void main(String[] args) 
	{
		PersonDemo p =new PersonDemo("Divya","Bharathi",'F',20,85.55f);
		System.out.println("Person Details:"+"\n"+"_______________"
		+"\n"+"\n"+p.dispPersonDetails());

	}

}
