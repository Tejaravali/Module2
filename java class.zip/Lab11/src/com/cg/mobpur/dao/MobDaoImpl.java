package com.cg.mobpur.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;




import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.exception.MobileException;
import com.cg.mobpur.util.DBUtil;

public class MobDaoImpl implements MobDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Scanner sc=new Scanner(System.in);
	Logger mobLogger=null;
	public MobDaoImpl() 
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		mobLogger=Logger.getLogger("MobDaoImpl.class");
	}

	@Override
	public int insertCustomer(Purchase ps) throws MobileException
	{
		String insertQry="INSERT INTO purchasedetails(purchaseId,cName,mailId,"
				+ "mobileNumber,purchaseDate, mobileId)"
				+ " VALUES(?,?,?,?,sysdate,?)";
		int dataAdded=0; 
		
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,generatePurchaseId());
			pst.setString(2, ps.getcName());
			pst.setString(3,ps.getMailId());
			pst.setLong(4, ps.getMobileNumber());
			pst.setInt(5,ps.getMobileId());
			dataAdded=pst.executeUpdate();
			 mobLogger.info("Purchase details inserted "+ps);
		}
		catch(Exception e)
		{
			mobLogger.error("This is exception :"+e.getMessage());
			throw new MobileException(e.getMessage());
		}

		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{

				throw new MobileException(e.getMessage());
			}
		}
			return dataAdded;
		}

	

	@Override
	public int generatePurchaseId() throws MobileException 
	{
		String qry="SELECT pur_seq.NEXTVAL FROM DUAL";
		int generatedVal=0;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);

		}
		catch(Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new MobileException(e.getMessage());
			}
		}
		return generatedVal;
	}

	@Override
	public ArrayList<Mobile> getAllMob() throws MobileException 
	{
		ArrayList<Mobile> mobList=new ArrayList<Mobile>();
		String selectQry="SELECT * FROM Mobile";
		Mobile mob = null;

		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			mobLogger.info("ALL MOBILE RECORDS ARE");
			while(rs.next())
			{
				mob=new Mobile(rs.getInt("mobileId"),
						rs.getString("name"),
						rs.getFloat("price"),
						rs.getInt("quantity"));
				        mobList.add(mob);
				        mobLogger.info(mob);
			}
		}
		catch(Exception e)
		{
			throw new MobileException(e.getMessage());

		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new MobileException(e.getMessage());
			}
		}

		return mobList;
	}

	@Override
	public ArrayList<Integer> getAllMobIds() throws MobileException 
	{
		String selectQry="SELECT mobileId FROM mobile";
		ArrayList<Integer> idList=new ArrayList<Integer>();
		
		int mobId;

		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				mobId=rs.getInt(1);
				idList.add(mobId);
			}
		}
		catch(Exception e)
		{
			throw new MobileException(e.getMessage());

		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new MobileException(e.getMessage());
			}
		}

		return idList;
	}

	@Override
	public int getAllMobQuantity(Purchase ps) throws MobileException
	{
		String qry="SELECT quantity FROM mobile where mobileId=?";
		int quantity=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry);
			pst.setInt(1, ps.getMobileId());
			rs=pst.executeQuery();
			rs.next();
			quantity=rs.getInt(1);

		}
		catch(Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				mobLogger.error("This is exception :"+e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		return quantity;
	}



	@Override
	public int updateQuantity(int mobileId) throws MobileException
	{
			String updateQry="UPDATE mobile Set quantity=quantity-1 where mobileId=?";
			int dataUpdated=0;
			try
			{
				con=DBUtil.getCon();
				pst=con.prepareStatement(updateQry);
				pst.setInt(1, mobileId);
				dataUpdated=pst.executeUpdate();
				mobLogger.info("Number of rows updates are "+dataUpdated);
			}
			catch(Exception e)
			{
				mobLogger.error("This is exception :"+e.getMessage());
				throw new MobileException(e.getMessage());
			}
			finally
			{
				try
				{
					rs.close();
					pst.close();
					con.close();
				}
				catch(SQLException e)
				{
					throw new MobileException(e.getMessage());
				}
			}
			return dataUpdated;
		}



	@Override
	public int deleteMobile(int mobileId) throws MobileException 
	{
		String deleteQry="DELETE FROM mobile where mobileId=?";
		int dataDeleted=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(deleteQry);
			pst.setInt(1, mobileId);
			dataDeleted=pst.executeUpdate();
			mobLogger.info("Number of rows deleted are "+dataDeleted);
			
		}
		catch(Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try
			{
				
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				 mobLogger.error("This is exception :"+e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		return dataDeleted;
	}
	
   @Override
	public ArrayList<Mobile> searchMobile(float min, float max)
			throws MobileException
	{
	   String selectQry="select * from mobile where price between ? and ?";
	   ArrayList<Mobile> mobList=new ArrayList<Mobile>();
	   Mobile m=null;
	   try
	   {
		   con=DBUtil.getCon();
		   pst=con.prepareStatement(selectQry);
		   pst.setFloat(1, min);
		   pst.setFloat(2, max);
		   rs=pst.executeQuery();
		   mobLogger.info("SELECTED RECORDS ARE");
		   while(rs.next())
		   {
			   m=new Mobile(rs.getInt(1),rs.getString(2),rs.getFloat(3),rs.getInt(4));
			   mobList.add(m);
			   mobLogger.info(m);
		   }
	   }
	   catch(Exception e)
	   {
		   throw new MobileException(e.getMessage());
	   }
	   finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new MobileException(e.getMessage());
			}
		}
	   return mobList;
	}
}



	

		

	



















