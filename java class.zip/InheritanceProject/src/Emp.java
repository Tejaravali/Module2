
public class Emp 
{
	private int empId;
	private String empName;
	private float empsal;
	static int empCount;
	
	static
	{
		System.out.println("Emp static block :");
		empCount=5;
	}
	
	public int getEmpId() 
	{
		return empId;
	}
	public void setEmpId(int empId)
	{
		this.empId = empId;
	}
	public String getEmpName()
	{
		return empName;
	}
	public void setEmpName(String empName)
	{
		this.empName = empName;
	}
	public float getEmpsal() 
	{
		return empsal;
	}
	public void setEmpsal(float empsal) 
	{
		this.empsal = empsal;
	}
	public Emp(int empId, String empName, float empsal) 
	{
	
		this.empId = empId;
		this.empName = empName;
		this.empsal = empsal;
		empCount++;
	}
	public Emp() 
	{
		
	}

	public String dispEmpInfo() 
	{
		return "Emp [empId=" + empId + 
				", empName=" + empName + 
				", empsal="
				+ empsal + "]";
	}
	
	public static void getCount()
	{
		System.out.println("Emp Count Is:"+empCount);
	}
	
}
