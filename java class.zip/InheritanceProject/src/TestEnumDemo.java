enum Seasons
{
	SUMMER,RAINY,WINTER;
	
}
public class TestEnumDemo {

	public static void main(String[] args)
	{
		Seasons currentSeason=Seasons.WINTER;
		System.out.println("Its "+currentSeason );

	}

}
