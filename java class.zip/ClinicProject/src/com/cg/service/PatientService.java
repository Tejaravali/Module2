package com.cg.service;

import java.util.ArrayList;
import java.util.regex.Pattern;
import com.cg.bean.PatientBean;
import com.cg.dao.IPatientDAO;
import com.cg.dao.PatientDAO;
import com.cg.exception.PatientException;

public class PatientService implements IPatientService 
{
	IPatientDAO pDao = new PatientDAO();
	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException {
		
		return pDao.addPatientDetails(patient);
	}

	@Override
	public PatientBean getPatientDetails(int patientId) throws PatientException {
		
		return pDao.getPatientDetails(patientId);
	}

	@Override
	public int generatePatientId() throws PatientException {
	
		return pDao.generatePatientId();
	}

	@Override
	public boolean isValidPatient(PatientBean patient) throws PatientException 
	{

		int flag=0;
		//System.out.println("First Name "+applicant.getfName());
		//System.out.println("LastName "+applicant.getlName());
		if(validatePatientName(patient.getPatientName()))
		{
			if(validatepAge(patient.getpAge()))
			{
				if(validatePhoneNo(patient.getPhoneNo()))
				{
					if(validateDescr(patient.getDescr()))
					{
						
								flag=1;
							
						
					}
				}
			}
		}
		if(flag==1)
		{
			return true;
		}
		else
		{
			throw new PatientException(" May Have some Exception while validating");
		}
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public boolean validatePatientId(int patientId) throws PatientException 
	{
		  pDao = new PatientDAO();
		  ArrayList<Integer> ptList=pDao.getAllPatIds();
	         for(Integer i:ptList)
	         {
	             if(patientId==i)
	             {
	                 return true;
	             }
	         }
	     
	     return false;
	 }

	private boolean validateDescr(String descr) throws PatientException
	{
		String descrPattern="[A-Z][a-z]{2,}";
		if(Pattern.matches(descrPattern,descr))
		{
			return true;
		}

		else  
		{
			throw new PatientException("Only Alphabets Allowed");
		}
		
	}

	private boolean validatePhoneNo(String phoneNo) throws PatientException
	{
		String phoneNoPattern="[7-9][0-9]{9}";
		if(Pattern.matches(phoneNoPattern,phoneNo))
		{
			return true;
		}
		else
		{
			throw new PatientException("Contact number should be a 10 digit valid mobile number");
		}
		
	}

	private boolean validatepAge(int pAge) throws PatientException
	{
		String pAgePattern="[0-9]{2}";
		if(Pattern.matches(pAgePattern, new Integer(pAge).toString()))
		{
			return true;
		}
		else
		{
			throw new PatientException("Age should contain only numbers");
		}
		
	}

	private boolean validatePatientName(String patientName) throws PatientException
	{
		String patientNamePattern="[A-Z][a-z]{2,}";
		if(Pattern.matches(patientNamePattern,patientName))
		{
			return true;
		}

		else  
		{
			throw new PatientException("Only Alphabets Allowed and starts with Capital"
					+ " and minimum 2 alphabets are required e.g Rishab");
		}
		
	}

	@Override
	public int deletePatient(int patientId) throws PatientException
	{
		
		return pDao.deletePatient(patientId);
	}

	@Override
	public ArrayList<PatientBean> getAllPatientDetails()
			throws PatientException 
			{
		return pDao.getAllPatientDetails();
			}

	@Override
	public ArrayList<Integer> getAllPatIds() throws PatientException 
	{
		return pDao.getAllPatIds();
	}
	
}
