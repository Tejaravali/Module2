package com.cg.exception;

public class PatientException extends Exception
{
	public PatientException(String msg)
    {
  	  super(msg);
    }
}
