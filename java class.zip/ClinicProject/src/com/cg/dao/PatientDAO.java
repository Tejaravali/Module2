package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.PatientBean;
import com.cg.exception.PatientException;
import com.cg.util.DBUtil;

public class PatientDAO implements IPatientDAO
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger patLogger=null;
	public PatientDAO()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		patLogger=Logger.getLogger("PatientDAO.class");
	}

	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException
	{
		String insertQry="INSERT INTO Patient(patient_id,patient_name,age,phone,description,consultation_date) VALUES(?,?,?,?,?,sysdate)";
		int dataAdded=0;  
		try
		{
			con=DBUtil.getCon();
		    pst=con.prepareStatement(insertQry);
			pst.setInt(1, generatePatientId());
			pst.setString(2, patient.getPatientName());
			pst.setInt(3,patient.getpAge());
			pst.setString(4,patient.getPhoneNo());
			pst.setString(5,patient.getDescr());
			dataAdded=pst.executeUpdate();
			patLogger.log(Level.INFO, "Pat Inserted :"+patient);
		}
		catch(Exception e)
		{
			
			throw new PatientException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				patLogger.error("This is Exception:"+e.getMessage());
				throw new PatientException(e.getMessage());
			}
		}
		return dataAdded;
	}

	public int generatePatientId() throws PatientException
	{
		String qry="SELECT Patient_Id_Seq.NEXTVAL FROM DUAL";
		int generatedVal=0;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);

		}
		catch(Exception e)
		{
			throw new PatientException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new PatientException(e.getMessage());
			}
		}
		return generatedVal;
	}

	@Override
	public PatientBean getPatientDetails(int patientId) throws PatientException
	{
		String searchQry="SELECT * from Patient where patient_id=?";
		PatientBean data=null;
		try
		{
			con=DBUtil.getCon();
		    pst=con.prepareStatement(searchQry);
			pst.setInt(1, patientId);
			rs = pst.executeQuery();
			while(rs.next())
			{
			data = new PatientBean(rs.getInt("patient_id"),rs.getString("patient_name"),rs.getInt("age"),rs.getString("phone"),rs.getString("description"),rs.getDate("consultation_date").toLocalDate());
		}
		}
		catch(Exception e)
		{
			throw new PatientException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new PatientException(e.getMessage());
			}
		}
		
		
		return data;
	}

	@Override
	public int deletePatient(int patientId) throws PatientException 
	{
		String deleteQry="DELETE FROM patient where patient_id=?";
		int dataDeleted=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(deleteQry);
			pst.setInt(1, patientId);
			dataDeleted=pst.executeUpdate();
			patLogger.info("Number of rows deleted are "+dataDeleted);
	   }
		catch(Exception e)
		{
			patLogger.error("This is exception :"+e.getMessage());
			throw new PatientException(e.getMessage());
		}
		finally
		{
			try
			{
				
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				 
				throw new PatientException(e.getMessage());
			}
		}
		
		return dataDeleted;
	}

	@Override
	public ArrayList<PatientBean> getAllPatientDetails()
			throws PatientException
			{
		 ArrayList<PatientBean> pList=new ArrayList<PatientBean>();
	      String selectQry="SELECT * FROM Patient";
	      PatientBean ee=null;
	      
	      try
	      {
	    	  con=DBUtil.getCon();
	    	  st=con.createStatement();
	    	  rs=st.executeQuery(selectQry);
	    	  patLogger.info("ALL MOBILE RECORDS ARE");
	    	  while(rs.next())
	    	  {
	    		  ee=new PatientBean(rs.getInt("patient_id"),rs.getString("patient_name"),rs.getInt("age"),rs.getString("phone"),rs.getString("description"),rs.getDate("consultation_date").toLocalDate());
	    		  pList.add(ee);
	    		  patLogger.info(ee);
	    	  }
	      }
	      catch(Exception e)
	      {
	    	  throw new PatientException(e.getMessage());
	    	  
	      }
	      finally
			{
				try
				{
					rs.close();
					st.close();
					con.close();
				}
				catch(SQLException e)
				{
					throw new PatientException(e.getMessage());
				}
			}
		
		return pList;
	}

	@Override
	public ArrayList<Integer> getAllPatIds() throws PatientException 
	{
		String selectQry="SELECT patient_id FROM Patient";
		ArrayList<Integer> ptList=new ArrayList<Integer>();
		
		int pId;

		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				pId=rs.getInt(1);
				ptList.add(pId);
			}
		}
		catch(Exception e)
		{
			throw new PatientException(e.getMessage());

		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new PatientException(e.getMessage());
			}
		}

		return ptList;
	}
}

