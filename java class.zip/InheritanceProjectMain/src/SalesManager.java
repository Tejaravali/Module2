
public class SalesManager extends wageEmp
{
	private int sales;
	private float commission;
	public SalesManager()
	  {
		  super();
		  
	  }
	public SalesManager(int empId,String empName,float empSal,int noOfHrs,
			int ratePerHrs,int sales,float commission)
	  {
		  super(empId,empName,empSal,ratePerHrs,noOfHrs);
		  this.sales=sales;
		  this.commission=commission;
	  }
	public float calcEmpBasicSal()
	  {
		  return super.calcEmpBasicSal()+(sales*commission);
	  }
	  public float calEmpAnnulSal()
	  {
		  return calcEmpBasicSal()*12;
	  }
		  

}
