import java.util.Scanner;


public class TestMedicineDemo
{

	public static void main(String[] args)
    {
		  Scanner sc=new Scanner(System.in);
	      System.out.println("How Many Medicines?");
	      int medCount=sc.nextInt();
	      Medicine medArr[]=new Medicine[medCount];
	      String medName=null;
	  	  String comName=null;
	  	  Date expDate;
	  	  float price=0.0F;
	  	 
	  	  int dd,mm,yyyy;
	  	for(int i=0;i<medArr.length;i++)
	  	{
              System.out.println("Enter Medicine Name: ");
	    	  medName=sc.next();
	    	  System.out.println("Enter Comp Name: ");
	    	  comName=sc.next();
	    	  System.out.println("Enter Exp Date as dd,mm,yyyy: ");
	    	  dd=sc.nextInt();
	    	  mm=sc.nextInt();
	    	  yyyy=sc.nextInt();
	    	  expDate=new Date(dd,mm,yyyy);
	    	  System.out.println("Enter the Price: ");
	    	  price=sc.nextInt();
	    	  System.out.println(" What Type Of Medicine U Want?" +
	                    "1:Tablet\t 2:Oinment \t 3:Syrup");
	    	  System.out.println("Enter Choice:");                   
	    	  int choice=sc.nextInt();
	    	  
	    	  switch(choice)
	    	  {
	    	     
	    	      case 1:
	    		      medArr[i]=new Tablet(medName,comName,expDate,price);
	    		      break;
	    	      case 2:
	    	    	  medArr[i]=new Sirup(medName,comName,expDate,price);
	    		      break;
	    	      default:
	    	    	  medArr[i]=new Oinment(medName,comName,expDate,price);
	    		      break;
	  	       }
		  }
	  	  System.out.println("****************************************");
	      for(int j=0;j<medArr.length;j++)
	      {
	    	  if(medArr[j] instanceof Oinment)
		    	 {
	    		  System.out.println("Oinment: "+medArr[j].dispMedInfo());
	    				  
		    	 }
	    	  else if(medArr[j] instanceof Sirup)
		    	 {
	    		  System.out.println("Sirup: "+medArr[j].dispMedInfo());
	    				  
		    	 }
	    	  else
		    	 {
	    		  System.out.println("Tablet: "+medArr[j].dispMedInfo());
	    				  
		    	 }
	    	  
	    	  
	      }

}
}






