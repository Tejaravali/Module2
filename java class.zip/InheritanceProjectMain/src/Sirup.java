
public class Sirup extends Medicine
{
	private String  caution;
	  
	  public Sirup()
	  {
		  super();
		  
	  }
	  public Sirup(String medName, String comName, Date expDate, float price)
	  {
		  super(medName,comName,expDate,price); 

		  
	  }
	  public String dispMedInfo()
	  {
		  caution="Shake Well Before Use";
		  return super.dispMedInfo()+"Caution:"+caution;
	  }
	  
	}

