
public class Medicine 
{
	private String medName;
	private String comName;
	 Date expDate;
	private float price;
	public Medicine()
	{
		expDate = new Date();
	}
	public Medicine(String medName, String comName, Date expDate, float price)
	{
		super();
		this.medName = medName;
		this.comName = comName;
		this.expDate = expDate;
		this.price = price;
	}
	public String dispMedInfo()
	{
		return "MedName:"+ medName +
				"\nComName:"+ comName +
				"\nDate:"+ expDate.dispDate() +
				"\nPrice:"+ price;
	
	}
	
	

}
