
public class Oinment extends Medicine
{
	private String  caution;
	  
	  public Oinment()
	  {
		  super();
		  
	  }
	  public Oinment(String medName, String comName, Date expDate, float price)
	  {
		  super(medName,comName,expDate,price); 
		
		  
	  }
	  public String dispMedInfo()
	  {
		  caution="For external use only";
		  return super.dispMedInfo()+"Caution:"+caution;
	  }
	  
	}


