
public class Tablet extends Medicine
{
	private String  caution;
  
  public Tablet()
  {
	  super();
	  
  }
  public Tablet(String medName, String comName, Date expDate, float price)
  {
	  super(medName,comName,expDate,price); 
	  
	  
  }
  public String dispMedInfo()
  {
	  caution="store in dry and cool place";
	  return super.dispMedInfo()+"Caution:"+caution;
  }
  
}
