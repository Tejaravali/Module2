
public class TestInheritanceDemo 
{
	
	public static void main(String args[])
	{
		Employee ravs=new Employee(111,"Ravs",20000.0F);
		wageEmp priya=new wageEmp(222,"Priya",5000.0F,5,400);
		System.out.println(" Emp Info: "+ravs.dispEmpInfo());
		System.out.println(" Emp Monthly Sal: "+ravs.calcEmpBasicSal());
		System.out.println(" Emp Annual Sal: "+ravs.calcEmpAnnulSal());
		
		System.out.println(" WageEmp Info: "+priya.dispEmpInfo());
		System.out.println(" Wage Emp Monthly Sal: "+priya.calcEmpBasicSal());
		System.out.println(" Wage Emp Annual Sal: "+priya.calcEmpAnnulSal());
		
		
		System.out.println();
		Employee krithika =new wageEmp(444,"Krithika",5000.0F,7,500);

		System.out.println(" WageEmp Info: "+krithika.dispEmpInfo());
		System.out.println(" Wage Emp Monthly Sal: "+krithika.calcEmpBasicSal());
		System.out.println(" Wage Emp Annual Sal: "+krithika.calcEmpAnnulSal());
		
		SalesManager sudhe = new SalesManager(555,"Sudheshna",5000.0F,7,500,100000,0.02F);
		System.out.println(" SalesManager Info: "+sudhe.dispEmpInfo());
		System.out.println(" Sales Manager Monthly Sal: "+sudhe.calcEmpBasicSal());
		System.out.println(" Sales Manager Annual Sal: "+sudhe.calcEmpAnnulSal());	
		
	}
}
