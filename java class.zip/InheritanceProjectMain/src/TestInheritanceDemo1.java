import java.util.Scanner;


public class TestInheritanceDemo1
{
    
	 public static void main(String args[])
	 {
	      Scanner sc=new Scanner(System.in);
	      System.out.println("How Many Employee?");
	      int empCount=sc.nextInt();
	      Employee empArr[]=new Employee[empCount];
	      int empId=0;
	      String empName=null;
	      float empSal=0.0F;
	      int noOfHrs=0;
	      int ratePerHrs=0;
	      for(int i=0;i<empArr.length;i++)
	      {
	    	  System.out.println("Enter Emp Id: ");
	    	  empId=sc.nextInt();
	    	  System.out.println("Enter Emp Name: ");
	    	  empName=sc.next();
	    	  System.out.println("Enter Emp Sal: ");
	    	  empSal=sc.nextInt();
	    	  System.out.println(" What Type Of Emp U Want?" +
	    	                    "1:Emp\t 2:wageEmp \t 3:SalesManager");
	    	  System.out.println("Enter Choice:");                   
	    	  int choice=sc.nextInt();
	    	  switch(choice)
	    	  {
	    	      case 1:empArr[i]=new Employee(empId,empName,empSal);
	    	      break;
	    	      case 2:
	    		      System.out.println("Enter number of Working Hours");
	    		      noOfHrs=sc.nextInt();
	    		      System.out.println("Enter Rate Per Hour");
	    		      ratePerHrs=sc.nextInt();
	    		      empArr[i]=new wageEmp(empId,empName,empSal,noOfHrs,ratePerHrs);
	    		      break;
	    	  default:
	    		  System.out.println("Enter number of hrs U worked");
	    		  noOfHrs=sc.nextInt();
	    		  System.out.println("Enter Rate Per Hour");
 		          ratePerHrs=sc.nextInt();
 		          System.out.println("Enter Sales U Have Done");
 		          int sales=sc.nextInt();
 		          System.out.println("Enter the Commission");
 		          float commission=sc.nextFloat();
 		          empArr[i]=new SalesManager(empId,empName,empSal,noOfHrs,ratePerHrs,sales,commission);
	    	      break;
	    	  }
	    	  
	    	  
	      }
	      System.out.println("****************************************");
	      for(int j=0;j<empArr.length;j++)
	      {
	    	 if(empArr[j] instanceof SalesManager)
	    	 {
	    		 System.out.println("Sales Manager: "+empArr[j].dispEmpInfo()+
	    				   " Monthly Basic Salary: "+empArr[j].calcEmpBasicSal()+
	    				    " Annual Salary: "+empArr[j].calcEmpAnnulSal());
	    	 }

	    	 else if(empArr[j] instanceof wageEmp)
	    	 {
	    		 System.out.println("Wage Emp: "+empArr[j].dispEmpInfo()+
	    				   " Monthly Basic Salary: "+empArr[j].calcEmpBasicSal()+
	    				    " Annual Salary: "+empArr[j].calcEmpAnnulSal());
	    	 }

	    	 else
	    	 {
	    		 System.out.println("Employee: "+empArr[j].dispEmpInfo()+
	    				   " Monthly Basic Salary: "+empArr[j].calcEmpBasicSal()+
	    				    " Annual Salary: "+empArr[j].calcEmpAnnulSal());
	    	 }
	    	 
	    	 
	      }
	    	  
	  }
	      
	 }

