import comm.cg.bat.Batch;
import comm.cg.stu.Student;

public class TestStudentDemo 
{

	public static void main(String[] args) 
	{
		Batch javaBatch = new Batch("JEE_Propel_001","8.30 To 6.00","Anjulatha");
        Batch vnvBatch = new Batch("VNV_PT_002","9.00 To 6.00","Shilpa");
        Batch orrAppBatch= new Batch("OraApp_ABridge_003","9.00To 6.00","Sachin");
        
        Student student1=new Student(111,"Ravs",90,javaBatch);
        Student student2=new Student(222,"Pari",60,javaBatch);
        Student student3=new Student(333,"Priya",70,vnvBatch);
        Student student4=new Student(444,"Devi",80,orrAppBatch);
        
        System.out.println(student1.dispStuInfo());
        System.out.println(student2.dispStuInfo());
        System.out.println(student3.dispStuInfo());
        System.out.println(student4.dispStuInfo());
        
        
		
		

	}

}
