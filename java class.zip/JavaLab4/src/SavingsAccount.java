
public class SavingsAccount extends Account
{
	private final double minimumBalance=5000;

	public SavingsAccount()
	{
		super();
		
	}

	public SavingsAccount(long accNum, double balance, Person accHolder)
	{
		super(accNum, balance, accHolder);


	}
	@Override
	public void withdraw(double amount)
	{
		if(minimumBalance>amount)
		{
		balance=balance-amount;
		System.out.println(amount+" is deducted from account");
	    }
		else
		{
			System.out.println("withdraw is not done");
		}
	
	}

	@Override
	public String toString() 
	{
		return super.toString();
	}

}
