
public class CurrentAccount extends Account
{
	private double overdraftLimit=100000;

	public CurrentAccount() 
	{
		super();
		
	}

	public CurrentAccount(long accNum, double balance, Person accHolder)
	{
		super(accNum, balance, accHolder);
		
	}
	public void withdraw(double amount)
	{
		if(overdraftLimit>amount)
		{
		amount=overdraftLimit-amount;
		System.out.println(amount+" is deducted from account");
	    }
		else
		{
			System.out.println("withdraw is not possible");
		}
		
		
		
	}

	@Override
	public String toString() 
	{
		return super.toString();
	}
   
	}

	
	
	


