 @FunctionalInterface
interface MaxFinder
 
{
   public int max(int num1,int num2);
}
public class TestScannerDemo
{
   public static void main(String[] args)
   {
	   MaxFinder  mf=(num1,num2)->num1>num2?num1:num2;
	   System.out.println("Greatest number is :"+ mf.max(60, 90));
   }
}
