import java.util.function.Consumer;
import java.util.function.Supplier;

@FunctionalInterface
interface MaxFind
 
{
   public int max(int num1,int num2);
}
public class LambdaDemo 
{
	public static void main(String[] args)
	{
		Consumer<String> consumer=(String str)->
		System.out.println(str);
		consumer.accept("Welcome");
		Supplier<String> sup= ()->"Happy New year";
		System.out.println(sup.get());
		BiFunction<Integer, Integer, Integer>
		biFunction=(x,y)->x>y?x:y;
		System.out.println("Greatest number is:"+biFunction.apply(90,80));
		
		
		
	}

}
