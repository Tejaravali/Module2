import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;


public class TestStreamApiDemo
{
	public static void main(String[] args)
	{
		List<String> cityList=Arrays.asList("pune"," ","Mumbai","Nagpur",
				"Gazibad","Mumbai","Delhi");
		
		  cityList.stream().distinct().forEach(System.out::println);
		  System.out.println("*************");
		  long cityCount=cityList.stream().distinct().count();
		  System.out.println("How many cities?:" +cityCount);
		  System.out.println("*************");
		  cityList.stream().map(str->str.length()).distinct().forEach(System.out::println);
		  System.out.println("*************");
		  long emptyStrCont =  cityList.stream().filter
		  ((String str)->str.isEmpty()).count();
		  System.out.println("empty String :"+emptyStrCont);
		  
	}

}
