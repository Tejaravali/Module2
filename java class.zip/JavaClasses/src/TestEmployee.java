import java.util.Scanner;


public class TestEmployee {

	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		int empId=0;
		String empName=null;
		String temp=null;
		float empSal=0.0F;
		int n;
		System.out.println("Enter the no of Employees:");
		n=sc.nextInt();
		Employee emps[] = new Employee[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter EMP ID: ");
			empId=sc.nextInt();
			System.out.println("Enter EMP Name: ");
		    empName=sc.next();
		    System.out.println("Enter EMP Salary: ");
			empSal=sc.nextFloat();
	     emps[i]=new Employee(empId,empName,empSal);
		   
			}
	     for(int j=0;j<n;j++)
		 {
			 System.out.println("EMPLOYEE DETAILS :"+ emps[j].dispEmployee());
		
		 }
	}

}
