public class Employee
{
	private int empId;
	private String empName;
	private float empSal;
	
	public Employee()
	{
		empId=0;
		empName="UnKnown";
		empSal=0.0F;
		
	
	}
	public Employee(int empId,String empName,float empSal)
	{
		
		this.empId=empId;
		this.empName=empName;
		this.empSal=empSal;

	}
	public String dispEmployee()
	{
		return "Employee [empId=" + empId + 
				", empName=" + empName 
				+ ", empSal=" + empSal 
				+ "]";
	}
	public float calcBasicSal()
	{
		return empSal;
	}

};
