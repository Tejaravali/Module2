
public class TestEmployeeAggregationDemo {

	public static void main(String[] args) 
	{
		Date ravsDOJ=new Date(01,04,2015);
		Date priyaDOJ=new Date(13,12,2018);
		
		Employee ravs=new Employee(101,"RAVS",1000.0f,ravsDOJ);
		Employee priya=new Employee(102,"PRIYA",1000.0f,priyaDOJ);
		
		System.out.println(ravs.dispEmpInfo());
		System.out.println(priya.dispEmpInfo());
		

	}

}
