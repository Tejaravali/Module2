import java.util.Scanner;

public class TestEmployeeAggregationDemo1
{
	public static void main(String[] args) 
	{
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter the no of Employees:");
	int n;
	n=sc.nextInt();
	int empId=0;
	String empName=null;
	/*String temp=null;*/
	float empSal=0.0F;
	int day=0,mon=0,year=0;
    Employee emps[] = new Employee[n];
	for(int i=0;i<n;i++)
	{
		System.out.println("Enter EMP ID: ");
		empId=sc.nextInt();
		
		System.out.println("Enter EMP Name: ");
	    empName=sc.next();
	    
	    System.out.println("Enter EMP Salary: ");
		empSal=sc.nextFloat();
		
		System.out.println("Enter joining date as day,month,year:");
		day=sc.nextInt();
		mon=sc.nextInt();
		year=sc.nextInt();
		
		Date empDOJ = new Date(day,mon,year);
	    emps[i]=new Employee(empId,empName,empSal,empDOJ);
	   
	}
	for(int j=0;j<n;j++)
	{
		System.out.println(emps[j].dispEmpInfo());
	}
 }
}
