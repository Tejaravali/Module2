package com.cg.eis.service;

public class ServiceClass implements EmployeeService
{
	private String result=null;
	public String employeeServiceScheme(float empSal,String empDes)
	{
		if(empSal>5000 && empSal<20000 && empDes.equals("SystemAssociate"))
		{
			result="Scheme A";
		}
		else if(empSal>=20000 && empSal<40000 && empDes.equals("programmer"))
		{
			result="Scheme B";
		}
		else if(empSal>=40000  && empDes.equals("Manager"))
		{
			result="Scheme A";
		}
		else
		{
			result="No Scheme";
		}
		return result;
	}

}
