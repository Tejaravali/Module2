package com.cg.eis.pl;
import java.util.Scanner;
import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.ServiceClass;

public class TestEmpDemo 
{
	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		
		int empId;
		String empName;
		float empSal;
		String empDes;
		String empIns=null;
		Employee emps=null;
			System.out.println("Enter EMP ID: ");
			empId=sc.nextInt();
			System.out.println("Enter EMP Name: ");
		    empName=sc.next();
		    System.out.println("Enter EMP Salary: ");
			empSal=sc.nextFloat();
			System.out.println("Enter EMP Des: ");
			empDes=sc.next();
			ServiceClass s =new ServiceClass();
			emps=new Employee(empId,empName,empSal,empDes,s);
		    System.out.println(emps.dispEmpInfo());
		
		
	}

}
