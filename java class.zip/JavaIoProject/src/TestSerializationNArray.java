
import java.io.*;
import java.util.Scanner;


public class TestSerializationNArray
{

    public static void main(String[] args)
    {
  
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
        try 
        {
            fos = new FileOutputStream("EmpData2.obj");
            oos = new ObjectOutputStream(fos);
        } 
        catch (Exception e1) 
        {
            
            e1.printStackTrace();
        }
        
    try
    {
    	Scanner s=new Scanner(System.in);
    	//System.out.println("Enter the no of Employees:");
    	//int n=s.nextInt();
    	Emp emps[]=new Emp[3];
        for(int i=0;i<3;i++)
        {
      
        System.out.println("Enter emp id");
        int empId=s.nextInt();
        
        System.out.println("Enter emp Name");
        String empName=s.next();
        
        System.out.println("Enter emp salary");
        float empsal=s.nextFloat();
        emps[i]=new Emp(empId,empName,empsal);
        oos.writeObject(emps[i]);
        System.out.println("emp object is written in a file");
        }
    }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        }
    }