
import java.io.*;

public class TestDeserializationNDemo
{

    public static void main(String[] args)
    {
        
        FileInputStream fis=null;
        ObjectInputStream ois=null;
        try
        {
            fis = new FileInputStream("EmpData2.obj");
             ois = new ObjectInputStream(fis);
        } 
        
        catch (Exception e1)
        {
            
            e1.printStackTrace();
        }
        //int n=0;
        Emp emps=null;
        for(int i=0;i<3;i++)
        {   
        try 
        {
            emps=(Emp)ois.readObject();
            System.out.println(emps);
        } 
         catch (Exception e)
        {
            e.printStackTrace();
        }
            
            System.out.println("emp object is written in a file");
            }
        }
        
        
    }

