import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class TestDeserializable
{

	public static void main(String[] args) 
	
	{
		 Emp e2=new Emp();
	     FileInputStream fis;
	     try
	     {
	    	 fis=new FileInputStream("EmpData.obj");
	    	 ObjectInputStream ois=new ObjectInputStream(fis);
	    	 e2=(Emp)ois.readObject();
	    	 System.out.println(e2);
	    	 System.out.println("Emp Object is written in a file ");
	     }
	     catch(Exception e)
	     {
	    	 e.printStackTrace();
	     }


	}

}
