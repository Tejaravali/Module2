
public abstract class Account1
{


	private long accNum;
	public double balance;
	Person1 accHolder;
	public long getAccNum() 
	{
		return accNum;
	}
	public void setAccNum(long accNum)
	{
		this.accNum = accNum;
	}
	
	public void setBalance(double balance) 
	{
		this.balance = balance;
	}
	public Person1 getAccHolder() 
	{
		return accHolder;
	}
	public void setAccHolder(Person1 accHolder)
	{
		this.accHolder = accHolder;
	}
	public Account1() {
		super();
		
	}
	public Account1(long accNum, double balance, Person1 accHolder) {
		super();
		this.accNum = accNum;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}

	public abstract void withdraw(double amount);
	
	public double getBalance() 
	{
		return balance;
	}
}



