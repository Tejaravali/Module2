
public class withdraw extends Account1
{
   @Override
   public void withdraw(double amount)
   {
	   double balance=super.getBalance();
	   balance=balance-amount;
	   super.setBalance(balance);
   }
}
