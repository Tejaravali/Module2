
public class TestAccount 
{

	public static void main(String[] args) 
	{
		withdraw w=new withdraw();
		long accNum=Math.round(Math.random()*10000);
		Person1 p=new Person1("ravali",22);
		w.setAccNum(624578914);
		w.getAccNum();
		w.getBalance();
		w.getAccHolder();
		w.setAccHolder(p);
		w.setBalance(50000);
		w.withdraw(20000);
		System.out.println(w.toString());
		
		

	}

}
