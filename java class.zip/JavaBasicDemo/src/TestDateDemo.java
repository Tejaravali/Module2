
public class TestDateDemo {

	public static void main(String[] args) 
	{
		Date ravsDOJ = new Date(13, 12, 2017);
		System.out.println("Ravali DOJ is : "+ ravsDOJ.dispDate());
	
	    Date vaiDOJ=new Date(03, 04, 2013);
	    System.out.println("Vaishali DOJ IS : "+vaiDOJ.dispDate());
	
	   Date unknownPerson=new Date();
	   System.out.println("Unknown DOJ IS : "+unknownPerson.dispDate());
	
	
	}
	

}

