
public class TestEmployee
{
	public static void main(String[] args) 
	{
		Employee emp1 = new Employee(101,"PRIYA",3000.0F,'F');
		System.out.println("emp1 Details are : "+ emp1.dispEmployee());
		
		Employee emp2 = new Employee(102,"PARI",4000.0F,'F');
		System.out.println("emp2 Details are : "+ emp2.dispEmployee());
		
		Employee emp3 = new Employee(103,"SUDHE",5000.0F,'F');
		System.out.println("emp3 Details are : "+ emp3.dispEmployee());
	
	}   
}
