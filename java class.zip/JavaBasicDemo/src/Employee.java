
public class Employee
{
	private int empId;
	private String empName;
	private float empSal;
	private char empGen;
	
	public Employee()
	{
		empId=0;
		empName="UnKnown";
		empSal=0.0F;
		empGen=' ';
		System.out.println("Empty Cons Called");
	}
	public Employee(int empId,String empName,float empSal,char empGen)
	{
		this();
		this.empId=empId;
		this.empName=empName;
		this.empSal=empSal;
		this.empGen=empGen;
	}
	public String dispEmployee()
	{
		return "Employee [empId=" + empId + 
				", empName=" + empName 
				+ ", empSal=" + empSal 
				+ ", empGen=" + empGen +"]";
	}
	public float calcBasicSal()
	{
		return empSal;
	}

};

