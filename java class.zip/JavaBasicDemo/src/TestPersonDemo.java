
public class TestPersonDemo {

	public static void main(String[] args)
	{
	   Person p1 = new Person("Ravs","CBH78GOP",10);
	   Person p2 = new Person("Raju","GLK98KJL",20);
	   Person p3 = new Person("Ravs","CBH78GOP",10);
	   Integer i1=new Integer(20);
	   Integer i2=new Integer(30);
	   Integer i3=new Integer(20);
	   
	   System.out.println("i1="+i1);
	   System.out.println("i2="+i2);
	   System.out.println("i3="+i1);
	   
	   if(i1.equals(i3))
	   {
		   System.out.println("Hey we r same");
	   }
	   else
	   {
		   System.out.println(" we are different");
	   }
	   System.out.println("HashCode of p1 :"+p1.hashCode());
	   System.out.println("HashCode of p2 :"+p2.hashCode());
	   System.out.println("HashCode of p3 :"+p3.hashCode());
	   System.out.println("HashCode of i1 :"+i1.hashCode());
	   System.out.println("HashCode of i2 :"+i2.hashCode());
	   System.out.println("HashCode of i3 :"+i3.hashCode());
	}

}
