package com.cg.global.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.global.bean.EnquiryBean;
import com.cg.global.exception.ContactBookException;
import com.cg.global.util.DBUtil;
public class ContactBookDaoImpl implements ContactBookDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Scanner sc=new Scanner(System.in);
	Logger mobLogger=null;
	public ContactBookDaoImpl() 
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		mobLogger=Logger.getLogger("ContactBookDaoImpl.class");
	}



	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		/*******INSERTIG VALUES INTO ENQUIRY TABLE***********/
		
		String insertQry="INSERT INTO enquiry(enqryId,firstName,lastName,contactNo,domain,city) VALUES(?,?,?,?,?,?)";
		int dataAdded=0;  
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, generateEnquiryId());
			pst.setString(2, enqry.getFname());
			pst.setString(3,enqry.getLname());
			pst.setString(4,enqry.getContactNo());
			pst.setString(5,enqry.getpLocation());
			pst.setString(6,enqry.getpDomain());
			dataAdded=pst.executeUpdate();
			mobLogger.info("Enquiry Details inserted "+enqry);
		}
		catch(Exception e)
		{
			
			mobLogger.error("This is exception :"+e.getMessage());
            throw new ContactBookException (e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				
              throw new ContactBookException (e.getMessage());
			}
		}
		return dataAdded;
	}

/************ VIEW DETAILS BASED ON ENQUIRY ID*******/
	@Override
	public ArrayList<EnquiryBean> getEnquiryDetails() throws ContactBookException 
	{
		ArrayList<EnquiryBean> enqList=new ArrayList<EnquiryBean>();
		String qry="SELECT * FROM EnquiryBean where enqryId=?";
		int details=0;
		EnquiryBean enq=null;
		try
		{
			enq=new EnquiryBean();
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry);
			pst.setInt(1,enq.getEnqryId());
			rs=pst.executeQuery();
			rs.next();
			mobLogger.info("Number of rows fetched are ");
			
			while(rs.next())
			{
				enq=new EnquiryBean(rs.getInt("enqryId"),
						rs.getString("Fname"),
						rs.getString("Lname"),
						rs.getString("ContactNo"),
						rs.getString("pLocation"),
						rs.getString("pDomain"));
						enqList.add(enq);
						mobLogger.info(enq);
				        
			}

		}
		catch(Exception e)
		{
			
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				pst.close();
				con.close();
			}
			catch(SQLException e)
			{
				
				throw new ContactBookException(e.getMessage());
			}
		}
		
		return enqList;
	}
/*************************GENERATING ENQUIRY ID*******************/
	@Override
	public int generateEnquiryId() throws ContactBookException 
	{
		String qry="SELECT enquiries.NEXTVAL FROM DUAL";
		int generatedVal=0;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);

		}
		catch(Exception e)
		{
			mobLogger.error("This is exception :"+e.getMessage());
			throw new  ContactBookException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch(SQLException e)
			{
				throw new  ContactBookException(e.getMessage());
			}
		}
		return generatedVal;
	}

}


