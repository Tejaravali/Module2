package com.cg.global.junit;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;


import com.cg.global.bean.EnquiryBean;
import com.cg.global.dao.ContactBookDao;
import com.cg.global.dao.ContactBookDaoImpl;
import com.cg.global.exception.ContactBookException;



public class TestEnquiry 
{
	   static ContactBookDao conDao=null;
	   static EnquiryBean enq = null;
	   
	   @BeforeClass	
	   public static void beforeClass() throws ContactBookException
	   {
		   conDao=new ContactBookDaoImpl();
		   enq=new EnquiryBean(conDao.generateEnquiryId(),"Lava","Kusha","9440129875","Java","Pune");
	   }
	   @Test
	   public void testAddEnq() throws ContactBookException
	   {
		   Assert.assertEquals(1,conDao.addEnquiry(enq));
	   }
	  @Test(expected=Exception.class)
	  public void testAddEmp2() throws ContactBookException
	  {
		   Assert.assertEquals(1,conDao.addEnquiry(enq));
	   }

}
