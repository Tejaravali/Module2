package com.cg.global.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.global.bean.EnquiryBean;
import com.cg.global.dao.ContactBookDao;
import com.cg.global.dao.ContactBookDaoImpl;
import com.cg.global.exception.ContactBookException;



public class ContactBookServiceImpl implements ContactBookService
{
	ContactBookDao conDao = null;

	public ContactBookServiceImpl()
	{
		conDao=new ContactBookDaoImpl();

	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		return conDao.addEnquiry(enqry);
	}

	@Override
	public ArrayList<EnquiryBean> getEnquiryDetails()
			throws ContactBookException
			{
		return conDao.getEnquiryDetails();
			}
    @Override
	public boolean validateContactNo(String contactNo) throws  ContactBookException
	{

		String numPattern="[7-9][0-9]{9}";
		if(Pattern.matches(numPattern, new Long(contactNo).toString()))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Mobile number must be valid");
		}
	}
    @Override
	public boolean validateFirstName(String fName) throws ContactBookException
	{
		String namePattern="[A-Z][a-z]{3,19}";
		if(Pattern.matches(namePattern, fName))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Only Chars Allowed and starts "
					+ "with Capital");
		}

	}
    @Override
	public boolean validateLastName(String lName) throws ContactBookException
	{
		String namePattern="[A-Z][a-z]{3,19}";
		if(Pattern.matches(namePattern, lName))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Only Chars Allowed and starts "
					+ "with Capital");
		}
	}
    @Override
	public boolean validatePLocation(String pLocation) throws ContactBookException
	{
		String namePattern="[A-Z][a-z]{3,19}";
		if(Pattern.matches(namePattern, pLocation))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Only Chars Allowed and starts "
					+ "with Capital");
		}
	}
    @Override
	public boolean validatePDomain(String pDomain) throws ContactBookException
	{
		String namePattern="[A-Z][a-z]{3,19}";
		if(Pattern.matches(namePattern, pDomain))
		{
			return true;
		}
		else
		{
			throw new ContactBookException("Only Chars Allowed and starts "
					+ "with Capital");
		}
	}
}
